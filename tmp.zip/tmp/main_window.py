import pygame


from gui.panels.control_panel import ControlPanel
from gui.dialogs.dialog import Dialog
from gui.widgets.check_box import CheckBox
from gui.widgets.text_window import TextWindow
from gui.theme import Theme
from core.config import Config 


class MainWindow:

    def __init__(
        self,
        screen,
        gui,
        image_loader,
        font_manager,
        session,
        player

    ):
        self.session = session
        self.player = player

        # print("Session loaded:", self.session._filename)
        # print(self.session)
        # print(self.session.name)
        # print(self.session.count())
        # print(self.session.current())
        # print(self.session.next())



        self.screen = screen
        self.gui = gui

        self.background_color = (30, 30, 30)

        self.control_panel = ControlPanel(
            image_loader,
            font_manager
        )

        self.font_manager = font_manager

        # Активный модальный диалог
        self.active_dialog = None

        # Проверка для отладки  CheckBox
        self.cb_test = CheckBox(

            rect=(40, 40, Theme.CB_SIZE, Theme.CB_SIZE),
            caption="Show translation",
            font=self.font_manager.load(
                14,
                Config.FONT_REGULAR
            ),
            checked=False
        )

        self.tw_test = TextWindow(

        rect=(40, 60, 400, 300),
        font=font_manager.load(
            32,
            Config.FONT_REGULAR
        ),
        text="This is a very long text that should automatically wrap inside the text window.",
        align="left"
        )    

    # --------------------------------------------------
    # Показать диалог выхода
    # --------------------------------------------------

    def show_exit_dialog(self):

        self.active_dialog = Dialog(

            parent_rect=self.screen.get_rect(),

            font_manager=self.font_manager,

            title="Exit",

            message="Хотите завершить приложение \n Или еще немного поработаете ",

            buttons=[
                "Yes",
                "No",
                "Later",
                "Early",

                ],
            default_button=1     
        )

        self.active_dialog.show()

    # --------------------------------------------------
    # Обработка событий
    # --------------------------------------------------

    def handle_event(self, event):

        #
        # Если открыт модальный диалог,
        # он получает события первым.
        #

        if self.active_dialog:

            result = self.active_dialog.handle_event(event)

            if result == 0:

                return "quit"

            elif result == 1:

                self.active_dialog = None

            return None

        #
        # Если диалогов нет
        #

        if event.type == pygame.QUIT:

            self.show_exit_dialog()

            return None

        #
        # Передаем событие панели управления
        #

        command = self.control_panel.handle_event(event)

        if command == "quit":

            self.show_exit_dialog()
            return None

        if command:

            if command == "play":
                self.player.play()

            elif command == "pause":
                self.player.pause()

            elif command == "stop":
                self.player.stop()

            elif command == "next":
                self.player.next()
                
            elif command == "prev":
                self.player.prev()







            print(self.player.state)
            print("Команда:", command)


        result = self.cb_test.handle_event(event)

        # если пришел сигнал от чек бокса
        if result is not None:
            print(result)

    # --------------------------------------------------
    # Обновление
    # --------------------------------------------------

    def update(self):

        self.cb_test.update()

        if self.active_dialog:

            self.active_dialog.update()

        else:

            self.control_panel.update()

    # --------------------------------------------------
    # Отрисовка
    # --------------------------------------------------

    def draw(self):

        self.screen.fill(
            self.background_color
        )

        # Прорисовка TextWindows
        self.tw_test.draw(self.screen)

        # Чек бокс прорисовка
        self.cb_test.draw(self.screen)

        #
        # Основной интерфейс
        #

        self.control_panel.draw(
            self.screen
        )

        #
        # Модальный диалог
        #

        if self.active_dialog:

            self.active_dialog.draw(
                self.screen
            )